<?php
header('Location: http://gifanaprd.com/');
exit;
?>