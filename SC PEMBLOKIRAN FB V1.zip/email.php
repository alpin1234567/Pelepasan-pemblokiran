<?php
$emailku = 'jarancok676@gmail.com'; // Masukin email kamu disini
$downloadsc = 'https://pastelink.net/p0vtjqvr'; //TEMPAT DOWNLOAD SC TERBARU
?>